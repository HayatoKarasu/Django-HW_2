from django.shortcuts import render
from django.http import HttpResponse


def index2(request):
    print(request)
    return HttpResponse('<h1>Произвольный текст</h1>'
                        '<h2>на произвольной странице :)</h2>')


def just(request):
    return HttpResponse('<h1>Просто</h1>'
                        '<h2>попробовать</h2>'
                        '<h3>разные уровни</h3>')